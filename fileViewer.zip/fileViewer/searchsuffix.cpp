#include "searchsuffix.h"
#include "sendemailapi/smtpmime.h"


searchsuffix::searchsuffix(QDialog *parent)
    :QDialog(parent)
{
    this->resize(600,400);
    setWindowTitle( tr( "搜索文件" ) );
    QLabel *fileName = new QLabel(tr("文件名：（不区分大小写）"));
    QLabel *suffixName = new QLabel(tr("后缀名：（例：txt）"));
    QLabel *creatDate = new QLabel(tr("创建时间：（年  月  日）"));
    QLabel *lastDate = new QLabel(tr("最后修改时间：（年  月  日）"));
    QLabel *fileRout = new QLabel(tr("文件路径："));
    receivAddr = new QLineEdit;
    QStringList mlist;
    QStringList dlist;
    //ischecked = "0";
    mlist<<"01"<<"02"<<"03"<<"04"<<"05"<<"06"<<"07"<<"08"<<"09"<<"10"<<"11"<<"12";
    dlist<<"01"<<"02"<<"03"<<"04"<<"05"<<"06"<<"07"<<"08"<<"09";
    Year = new QComboBox(this); Year->clear();
    Month = new QComboBox(this); Month->clear();
    LYear = new QComboBox(this); LYear->clear();
    Date = new QComboBox(this); Date->clear();
    LMonth = new QComboBox(this); LMonth->clear();
    LDate = new QComboBox(this); LDate->clear();
    rout = new QLineEdit;
    Year->addItem(" ");
    LYear->addItem(" ");
    Month->addItem(" ");
    Date->addItem(" ");
    LMonth->addItem(" ");
    LDate->addItem(" ");
    for(int k=2000;k<=2016;k++){
        QString curY = QString::number(k, 10);
        Year->addItem(curY);
        LYear->addItem(curY);
    }
    Month->addItems(mlist);
    LMonth->addItems(mlist);
    Date->addItems(dlist);
    LDate->addItems(dlist);
    for(int k=10;k<=31;k++){
        QString curD = QString::number(k, 10);
        Date->addItem(curD);
        LDate->addItem(curD);
    }
    suffix = new QLineEdit;
    //rout = new QLineEdit;
    Name = new QLineEdit;

    //rout->setText( tr("Users/Nina") );
    sufListwidget = new QTreeWidget(this);
    QStringList headers;
    headers << "Name"<<"Path";
    sufListwidget->setHeaderLabels(headers);
    sufListwidget->setColumnWidth(0,450);

    /*
    db = QSqlDatabase::database("conn");
    query = new QSqlQuery(db);
    query->setForwardOnly(true);*/

    deskdb = QSqlDatabase::database("desk");
    queryd = new QSqlQuery(deskdb);
    queryd->setForwardOnly(true);

    QPushButton *searchbutton = new QPushButton(QObject::tr("&Search"));
    QVBoxLayout *sufleftLayout = new QVBoxLayout;
    QVBoxLayout *suftotalLayout = new QVBoxLayout;
    QHBoxLayout *sufrightLayout = new QHBoxLayout;
    //QHBoxLayout *sufrLayout1 = new QHBoxLayout;
    QHBoxLayout *sufrLayout2 = new QHBoxLayout;
    QHBoxLayout *sufrLayout3 = new QHBoxLayout;

        sufleftLayout->addWidget(fileName);
        sufleftLayout->addWidget(Name);
        sufleftLayout->addWidget(suffixName);
        sufleftLayout->addWidget(suffix);

        sufrLayout2->addWidget(Year);
        sufrLayout2->addWidget(Month);
        sufrLayout2->addWidget(Date);
        sufleftLayout->addWidget(creatDate);
        sufleftLayout->addLayout(sufrLayout2);

        sufrLayout3->addWidget(LYear);
        sufrLayout3->addWidget(LMonth);
        sufrLayout3->addWidget(LDate);

        sufleftLayout->addWidget(lastDate);
        sufleftLayout->addLayout(sufrLayout3);
        //sufleftLayout->addLayout(sufrLayout1);
        sufleftLayout->addWidget(searchbutton);
        sufrightLayout->addLayout(sufleftLayout);
        sufrightLayout->addWidget(sufListwidget);
        suftotalLayout->addLayout(sufrightLayout);
        suftotalLayout->addWidget(fileRout);
        suftotalLayout->addWidget(rout);
    setLayout(suftotalLayout);
    connect(searchbutton, SIGNAL(clicked(bool)), this, SLOT(searchsuff()) );
    connect( sufListwidget, SIGNAL( itemDoubleClicked( QTreeWidgetItem *,int ) ), this, SLOT( slotshowPath( QTreeWidgetItem * ) ) );
    sufListwidget->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(sufListwidget,SIGNAL(customContextMenuRequested(const QPoint&)),this,SLOT(popMenu(const QPoint&)));
}

searchsuffix::~searchsuffix()
{

}

void searchsuffix::getRoot(QString *root)
{
    rout->setText(*root);
}

void searchsuffix::searchsuff(){

    sufListwidget->clear();
    QDir sufDir;
    sufDir.setPath( rout->text() );
    QStringList ssList;
    ssList << "*";
    QFileInfoList suflist = sufDir.entryInfoList( ssList );
    QString fileN = Name->text();
    QString suf = suffix->text();
    QString Y = Year->currentText();
    QString M = Month->currentText();
    QString D = Date->currentText();
    QString LY = LYear->currentText();
    QString LM = LMonth->currentText();
    QString LD = LDate->currentText();
    if(fileN == ""&&suf == ""&&Y == " "&&M == " "&&D == " "&&LY == " "&&LM == " "&&LD == " ")
    {
        QMessageBox::warning(NULL, "warning", "请输入搜索关键字",
                                     QMessageBox::Ok |QMessageBox::Ok);
        return;
    }
    for ( unsigned int i = 0; i < suflist.count(); i++ )
    {
        QFileInfo suftmpFileInfo = suflist.at( i );
        if ( suftmpFileInfo.isDir() )
        {
            QString str2 = suftmpFileInfo.fileName();
            //QString str = suftmpFileInfo.baseName();
            if(str2!=".."&&str2!="."){
            searchremain(suftmpFileInfo.absoluteFilePath() );

            }
        }
     else{
           QString curN = suftmpFileInfo.baseName();
       if((suftmpFileInfo.suffix()==suf||suf == "")&&(matchNom(fileN,curN)||fileN == "")){
           QString curY = suftmpFileInfo.created().toString(QObject::tr("yyyy"));
           QString curM = suftmpFileInfo.created().toString(QObject::tr("MM"));
           QString curD = suftmpFileInfo.created().toString(QObject::tr("dd"));
           QString curLY = suftmpFileInfo.lastModified().toString(QObject::tr("yyyy"));
           QString curLM = suftmpFileInfo.lastModified().toString(QObject::tr("MM"));
           QString curLD = suftmpFileInfo.lastModified().toString(QObject::tr("dd"));
           if((Y == curY ||Y==" ")&&(M == curM || M == " ")&&(D == curD || D == " ")){
               if((LY == curLY || LY == " ")&&(LM == curLM || LM == " ")&&(LD == curLD||LD == " ")){
           QString fileName = suftmpFileInfo.fileName();
           QString filePath = suftmpFileInfo.absoluteFilePath();
           QStringList treeText;
           treeText << fileName<<filePath;
           QFileIconProvider iconPro;
           QIcon icon = iconPro.icon(suftmpFileInfo);
           QTreeWidgetItem *spTmp = new QTreeWidgetItem(sufListwidget, treeText);
           spTmp->setIcon(0,QIcon( icon));
           sufListwidget->addTopLevelItem(spTmp );
               }
          }
       }



       }
    }

}

void searchsuffix::searchremain(QString path)
{
    QString flag="0";
    QDir sufmDir;
    sufmDir.setPath( path );
    QStringList smsList;
    smsList << "*";
    QFileInfoList sufmlist = sufmDir.entryInfoList( smsList );
    QString suf = suffix->text();
    for ( unsigned int i = 0; i < sufmlist.count(); i++ )
    {
        QFileInfo sufmtmpFileInfo = sufmlist.at( i );
        if ( sufmtmpFileInfo.isDir() )
        {
            QString mstr = sufmtmpFileInfo.fileName();
            if(mstr!="."&&mstr!=".."){
            searchremain(sufmtmpFileInfo.absoluteFilePath() );

            }
        }
        else{
            QString curmN = sufmtmpFileInfo.baseName();
            QString filemN = Name->text();
        if((sufmtmpFileInfo.suffix()==suf || suf == "")&&(matchNom(filemN,curmN) || filemN == "")){

            QString mY = Year->currentText();
            QString mM = Month->currentText();
            QString mD = Date->currentText();
            QString LmY = LYear->currentText();
            QString LmM = LMonth->currentText();
            QString LmD = LDate->currentText();
            QString curmY = sufmtmpFileInfo.created().toString(QObject::tr("yyyy"));
            QString curmM = sufmtmpFileInfo.created().toString(QObject::tr("MM"));
            QString curmD = sufmtmpFileInfo.created().toString(QObject::tr("dd"));
            QString curmLY = sufmtmpFileInfo.lastModified().toString(QObject::tr("yyyy"));
            QString curmLM = sufmtmpFileInfo.lastModified().toString(QObject::tr("MM"));
            QString curmLD = sufmtmpFileInfo.lastModified().toString(QObject::tr("dd"));
            if((curmY == mY || mY==" ")&&(mM == curmM || mM == " ")&&(mD == curmD || mD == " ")){
                if((curmLY == LmY || LmY == " ")&&(LmM == curmLM || LmM == " ")&&(LmD == curmLD || LmD == " ")){
            QString fileName = sufmtmpFileInfo.fileName();
            QString filePath = sufmtmpFileInfo.absoluteFilePath();
            QStringList streeText;
            streeText << fileName<<filePath;
            QFileIconProvider iconPro;
            QIcon sicon = iconPro.icon(sufmtmpFileInfo);
            QTreeWidgetItem *smpTmp = new QTreeWidgetItem(sufListwidget, streeText);
            smpTmp->setIcon(0,QIcon( sicon ));
            sufListwidget->addTopLevelItem( smpTmp );

            flag="1";}
            }
        }
        }
    }

}


int searchsuffix::matchNom(QString nom, QString name)
{
    int i = name.indexOf(nom,0,Qt::CaseInsensitive);

    if(i==-1)
        return 0;
    else return 1;
}

void searchsuffix::slotshowPath(QTreeWidgetItem * sufitem)
{
    QString itemPath = sufitem->text(1);
    rout->setText(itemPath) ;

}

void searchsuffix::popMenu(const QPoint &)
{
    QTreeWidgetItem* curItem= sufListwidget->currentItem();
    if(curItem==NULL)return;
    QString wellName = curItem->text(0);
    if(wellName != "wells")
        {
            QAction readdetail(QString::fromLocal8Bit("&查看信息"),this);
            QAction deletefile(QString::fromLocal8Bit("&删除文件"),this);
            QAction updateConnection(QString::fromLocal8Bit("&桌面同步"),this);
            QAction sendfileEmail(QString::fromLocal8Bit("&发送邮件"),this);
            connect(&readdetail, SIGNAL(triggered()), this, SLOT(detailItem()));
            connect(&deletefile, SIGNAL(triggered()), this, SLOT(deleteItem()));
            connect(&sendfileEmail, SIGNAL(triggered()), this, SLOT(emailItem()));
            connect(&updateConnection, SIGNAL(triggered()), this, SLOT(updateItem()));
            QMenu menu(sufListwidget);
            menu.addAction(&readdetail);
            menu.addAction(&deletefile);
            menu.addAction(&updateConnection);
            menu.addAction(&sendfileEmail);
            menu.exec(QCursor::pos());  //在当前鼠标位置显示

        }

}

void searchsuffix::detailItem()
{
    QTreeWidgetItem* currItem=sufListwidget->currentItem();
    QString itemPath = currItem->text(1);

    QFileInfo filenew(itemPath);




    QDialog *fileDWindow = new QDialog(this);
    fileDWindow->setWindowTitle(tr("文件信息"));
    QLabel *fileN = new QLabel(tr("文件名:"));
    QLabel *fileS = new QLabel(tr("文件后缀:"));
    QLabel *fileR = new QLabel(tr("文件路径:"));
    QLabel *fileSZ = new QLabel(tr("文件大小"));
    QLabel *fileC = new QLabel(tr("创建时间:"));
    QLabel *fileE = new QLabel(tr("最后修改时间:"));
    QLineEdit *fileName = new QLineEdit(fileDWindow);
    QLineEdit *fileSuffix = new QLineEdit(fileDWindow);
    QLineEdit *fileRout = new QLineEdit(fileDWindow);
    QLineEdit *fileSize = new QLineEdit(fileDWindow);
    QLineEdit *fileCreated = new QLineEdit(fileDWindow);
    QLineEdit *fileEdit = new QLineEdit(fileDWindow);

    /*
    QString sqlN = QString("SELECT name,suffix,createdDate,lastModifiedD,size FROM FILE_INFO WHERE rout='%1'").arg(itemPath);
        query->exec(sqlN);
        if(query->first()){
        fileName->setText( query->value(0).toString());
        fileSuffix->setText("."+query->value(1).toString());
        fileCreated->setText(query->value(2).toString());
        fileEdit->setText(query->value(3).toString());
        fileSize->setText(query->value(4).toString());}
        else
    fileRout->setText(itemPath);
    */
    fileName->setText(filenew.baseName());
    fileSuffix->setText("."+filenew.suffix());
    fileRout->setText(itemPath);
    fileCreated->setText(filenew.created().toString(QObject::tr("yyyy年MM月dd日hh:mm")));
    fileEdit->setText(filenew.lastModified().toString(QObject::tr("yyyy年MM月dd日hh:mm")));
    char Unit = 'B';
    quint64 curSize = filenew.size();
    if(curSize>1024)
    {
        curSize/=1024; Unit = 'K';
        if(curSize>1024)
        {
            curSize/=1024; Unit = 'M';
            if(curSize>1024)
            {
                curSize/=1024; Unit = 'G';
            }
        }

    }
    QString filesize = QString::number(curSize, 10)+Unit;
    fileSize->setText(filesize);

    QGridLayout *gridLayout=new QGridLayout;
    gridLayout->setSizeConstraint(QLayout::SetFixedSize);
    //gridLayout->setSpacing(12);
    gridLayout->addWidget(fileN,0,0,1,1);
    gridLayout->addWidget(fileName,0,1,1,4);
    gridLayout->addWidget(fileS,0,15,1,1);
    gridLayout->addWidget(fileSuffix,0,16,1,4);
    gridLayout->addWidget(fileR,1,0,1,1);
    gridLayout->addWidget(fileRout,1,1,1,30);
    gridLayout->addWidget(fileSZ,2,0,1,1);
    gridLayout->addWidget(fileSize,2,1,1,4);
    gridLayout->addWidget(fileC,3,0,1,1);
    gridLayout->addWidget(fileCreated,3,1,1,4);
    gridLayout->addWidget(fileE,3,15,1,1);
    gridLayout->addWidget(fileEdit,3,16,1,15);

    fileDWindow->setLayout(gridLayout);
    fileDWindow->show();

}

void searchsuffix::deleteItem()
{
     if(QMessageBox::warning(NULL, "warning", "Do you want to delete this file?",
                             QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes) == QMessageBox::Yes)
     {
    QTreeWidgetItem* current = sufListwidget->currentItem();
    QString itemPath = current->text(1);
    DeleteDirectory(itemPath);
    delete current;
     }
}

bool searchsuffix::DeleteDirectory(QString path)
{
    QFileInfo deletefile(path);
    if(!deletefile.exists())
            return true;
    deletefile.dir().remove(deletefile.fileName());
    return true;

}



void searchsuffix::updateItem()
{
    QTreeWidgetItem* currItem=sufListwidget->currentItem();
    QString itemPath = currItem->text(1);
    QString itemName = currItem->text(0);
    QString ssql = QString("SELECT name FROM DESK_FILE WHERE sourceRoot='%5'").arg(itemPath);
    queryd->exec(ssql);
    if(queryd->first())
    {
        QMessageBox::warning(NULL, "warning", "连接到源文件的桌面同步文件已被删除",
                                      QMessageBox::Ok |QMessageBox::Ok);
        return;
    }

    QString DS(QStandardPaths::writableLocation(QStandardPaths::DesktopLocation));
    QString toDesktop(DS+"/");
    QDir sourceDir;
    QDir deskDir;
    QString newPath = toDesktop+itemName;
    deskDir.setPath(newPath);
    sourceDir.setPath(itemPath);
    QFile::copy(itemPath,newPath);
    QFileInfo filenew(itemPath);
    QString lastMD;
    lastMD = filenew.lastModified().toString(QObject::tr("yyyy年MM月dd日hh:mm"));
    /*QString sql = QString("SELECT lastModifiedD FROM FILE_INFO WHERE rout='%4'").arg(itemPath);
        query->exec(sql);
        if(query->first())
        lastMD = query->value(0).toString();*/

    QString dsql = QString("insert into DESK_FILE values('%1','%2','%3','%4')").arg(itemName)
            .arg(itemPath).arg(newPath).arg(lastMD);
    queryd->exec(dsql);
    /*QString sdql = QString("SELECT lastModifiedD FROM DESK_FILE WHERE sourceRoot='%4'").arg(itemPath);
        queryd->exec(sdql);
        if(queryd->first())
        {qDebug()<< queryd->value(0).toString();}*/
}

void searchsuffix::emailItem()
{
    //ischecked = "0";
    QDialog *receiverAddr = new QDialog(this);
    QLabel *rece = new QLabel(tr("收件人邮箱："));
    QPushButton *recebutton = new QPushButton(QObject::tr("&确认发送"));
    connect(recebutton,SIGNAL(clicked(bool)),this,SLOT(closeE()));
    QVBoxLayout *rLayout = new QVBoxLayout;
    rLayout->addWidget(rece);
    rLayout->addWidget(receivAddr);
    rLayout->addWidget(recebutton);
    receiverAddr->setLayout(rLayout);
    receiverAddr->show();
    connect(recebutton,SIGNAL(clicked(bool)),receiverAddr,SLOT(close()));

}


void searchsuffix::closeE()
{
    if(receivAddr->text() == "")
    {
        QMessageBox::warning(NULL, "warning", "请输入收件人邮箱地址！",
                             QMessageBox::Ok |QMessageBox::Ok);
        return;
    }
    QTreeWidgetItem* currItem=sufListwidget->currentItem();
    QString itemPath = currItem->text(1);
    QString itemName = currItem->text(0);
    //qDebug()<<itemPath;
    QString hostNm;
    QString termNb;
    QString UserNm;
    QString PassWN;
    QString esql = QString("SELECT * FROM EMAIL_INFO");
    queryd->exec(esql);
    if(queryd->first())
    {
     UserNm = queryd->value(0).toString();
     PassWN = queryd->value(1).toString();
     hostNm = queryd->value(2).toString();
     termNb = queryd->value(3).toString();
    }
    quint64 num = termNb.toInt();
    SmtpClient smtp(hostNm,num);
    smtp.setUser(UserNm);
    smtp.setPassword(PassWN);

    MimeMessage message;
    message.setSender(new EmailAddress(UserNm));
    QString receiver = receivAddr->text();
    message.addRecipient(new EmailAddress(receiver));
    message.setSubject(itemName);
    MimeHtml text;
    text.setHtml("sent from qt host");
    message.addPart(&text);

    QFile *attafile = new QFile(itemPath);
    if(attafile->exists())
    {
        message.addPart(new MimeAttachment(attafile));
    }

    if (!smtp.connectToHost()){
            QMessageBox::critical(this,"错误","服务器连接失败!");
            return;
        }
        if (!smtp.login()){
            QMessageBox::critical(this,"错误","用户登录失败!");
            return;
        }
        if (!smtp.sendMail(message)){
            QMessageBox::critical(this,"错误","邮件发送失败!");
            return;
        }else{
            QMessageBox::information(this,"错误","邮件发送成功!");
        }
    smtp.quit();
}


