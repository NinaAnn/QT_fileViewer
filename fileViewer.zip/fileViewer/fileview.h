#ifndef FILEVIEW_H
#define FILEVIEW_H
#include "filedb.h"
#include "searchsuffix.h"

#include <QDialog>
#include <QListWidget>
#include <QFileInfo>
#include <QDir>
#include <QLineEdit>
#include <QTreeWidgetItem>
#include <QTextEdit>
#include <QFile>
#include <QVBoxLayout>
#include <QPushButton>
#include <QDebug>
#include <QTreeWidget>

class fileview : public QDialog
{
    Q_OBJECT

public:
    fileview(QWidget *parent = 0);
    ~fileview();
signals:
    void sendRoot(QString *root );

protected slots:
    void slotShowDir( QTreeWidgetItem * item );
    void searchShow();
    void popupMenu(const QPoint &);
    void detailItem();
    void deleteItem();
    void updateItem();
    void emailItem();
    void sendE();

private:
    void showFileInfoList( QFileInfoList list );
       QTreeWidget *pListWidgetFile;
       QVBoxLayout *leftLayout;
       QLineEdit *pLineEditDir;
       QLineEdit *receivAddr;
       //QSqlDatabase db;
       //QSqlQuery *query;
       QSqlDatabase deskdb;
       QSqlQuery *queryd;
    bool DeleteDirectory(QString path);


};

#endif // FILEVIEW_H
