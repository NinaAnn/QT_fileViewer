#include "mainwindow.h"
#include "fileview.h"
#include "searchsuffix.h"
#include "updatefileinfo.h"
#include "showdconnect.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    //UpdatefileInfo();
    fileview *w = new fileview(this);
    //searchsuffix *s = new searchsuffix(this);
    showDConnect *c = new showDConnect(this);

    EAddress = new QLineEdit;
    EPassW = new QLineEdit;
    EPassW->setEchoMode(QLineEdit::Password);
    hostN = new QComboBox;
    terminalN = new QComboBox;
    QStringList hlist;
    hlist<<"smtp.163.com"<<"smtp.126.com"<<"smtp.139.com"<<"smtp.sina.com.cn"<<"smtp.sohu.com";
    QStringList tlist;
    tlist<<"25"<<"25"<<"25"<<"25"<<"25";
    hostN->addItems(hlist);
    terminalN->addItems(tlist);

    deskdb = QSqlDatabase::database("desk");
    queryd = new QSqlQuery(deskdb);
    queryd->setForwardOnly(true);

    if(!deskdb.tables().contains("DESK_FILE")){
    　if(!queryd->exec("create table DESK_FILE(name nvarchar(40), sourceRoot nvarchar(100),deskRoot nvarchar(100), "
                     "lastModifiedD nvarchar(20))"))
        qDebug()<<queryd->lastError();
}
    checkFile();
    QTimer *timer = new QTimer(this);
    QObject::connect( timer, SIGNAL(timeout()),this, SLOT(checkFile()) );
    timer->start( 1000);
    QPushButton *buttom = new QPushButton(QObject::tr("&文件浏览"));
    QPushButton *deskbuttom = new QPushButton(QObject::tr("&同步信息"));
    QPushButton *emailbuttom = new QPushButton(QObject::tr("&邮箱设置"));
    connect(buttom, &QPushButton::clicked, w, &fileview::show);
    connect(emailbuttom, SIGNAL(clicked(bool)), this, SLOT(addEmail()));
    connect(deskbuttom, &QPushButton::clicked, c, &showDConnect::show);
    connect(hostN,SIGNAL(currentIndexChanged(int)),terminalN,SLOT(setCurrentIndex(int)));
    //connect(terminalN,SIGNAL(currentIndexChanged(int)),hostN,SLOT(setCurrentIndex(int)));
    QVBoxLayout *mainLayout = new QVBoxLayout;
        mainLayout->addWidget(buttom);
        mainLayout->addWidget(emailbuttom);
        mainLayout->addWidget(deskbuttom);
    QWidget *mainWidget = new QWidget;
   mainWidget->setLayout(mainLayout);
   setCentralWidget(mainWidget);

}

MainWindow::~MainWindow()
{

}


void MainWindow::checkFile(){
        QString dsql = QString("SELECT deskRoot,lastModifiedD,sourceRoot FROM DESK_FILE");
        queryd->exec(dsql);
        if(queryd->first()){
        do
        {
            QString fPath = queryd->value(0).toString();
            QString LSm = queryd->value(1).toString();
            QString sPath = queryd->value(2).toString();
            QFileInfo destifile(fPath);
            QFileInfo sourcefile(sPath);
            if(!destifile.exists())
            {
                QString sourcefm = sourcefile.fileName();
                QString deletesql = QString("DELETE FROM DESK_FILE WHERE deskRoot = '%1'").arg(fPath);
                QMessageBox::warning(NULL, "warning", "连接到源文件"+sourcefm+"的桌面同步文件已被删除",
                                              QMessageBox::Ok |QMessageBox::Ok);
                queryd->exec(deletesql);
            }
            else if(!sourcefile.exists())
            {
                QString destifm = destifile.fileName();
                //QString warning = QString(tr();

                QMessageBox::warning(NULL, "warning", "连接到桌面"+destifm+"的源文件丢失",
                                              QMessageBox::Ok |QMessageBox::Ok);
                QString deletesql = QString("DELETE FROM DESK_FILE WHERE deskRoot = '%1'").arg(fPath);
                queryd->exec(deletesql);
            }
            else
            {
                if(destifile.lastModified().toString()!=LSm)
                {
                    sourcefile.dir().remove(sourcefile.fileName());
                    QDir sourceDir;
                    sourceDir.setPath(sPath);
                    QFile::copy(fPath,sPath);
                }
            }
    }while(queryd->next());
        }
}


void MainWindow::addEmail()
{
    QDialog *emailWindow = new QDialog(this);
    emailWindow->resize(300,200);
    emailWindow->setWindowTitle(tr("邮箱设置"));
    QLabel *emailA = new QLabel(tr("邮箱账号:"));
    QLabel *emailP = new QLabel(tr("邮箱密码:"));
    QLabel *hostName = new QLabel(tr("服务器:"));
    QLabel *terminalNum = new QLabel(tr("端口号:"));
    QPushButton *savebutton = new QPushButton(QObject::tr("&保存设置"));

    if(!deskdb.tables().contains("EMAIL_INFO")){
        if(!queryd->exec("create table EMAIL_INFO(mailaddress nvarchar(100), password nvarchar(100),"
                         " hostname nvarchar(40), terminalnumber nvarchar(10))"))
       qDebug()<<queryd->lastError();
}
    QString selectql = QString(" SELECT * FROM EMAIL_INFO");
    queryd->exec(selectql);
    if(queryd->first())
    {
        const QString hostNM = queryd->value(2).toString();
        const QString termN = queryd->value(3).toString();
        EAddress->setText(queryd->value(0).toString());
        EPassW->setText(queryd->value(1).toString());
        hostN->setCurrentText(hostNM);
        terminalN->setCurrentText(termN);
    }

    QHBoxLayout *rLayout1 = new QHBoxLayout;
    QHBoxLayout *rLayout2 = new QHBoxLayout;
    QHBoxLayout *rLayout3 = new QHBoxLayout;
    QHBoxLayout *rLayout4 = new QHBoxLayout;
    rLayout1->addWidget((emailA));
    rLayout1->addWidget(EAddress);
    rLayout2->addWidget(emailP);
    rLayout2->addWidget(EPassW);
    rLayout3->addWidget(hostName);
    rLayout3->addWidget(hostN);
    rLayout4->addWidget(terminalNum);
    rLayout4->addWidget(terminalN);

    QVBoxLayout *Layout = new QVBoxLayout;
    Layout->addLayout(rLayout1);
    Layout->addLayout(rLayout2);
    Layout->addLayout(rLayout3);
    Layout->addLayout(rLayout4);
    Layout->addWidget(savebutton);
    emailWindow->setLayout(Layout);

    connect(savebutton, SIGNAL(clicked(bool)), this, SLOT(saveEmail()));
    connect(savebutton,SIGNAL(clicked(bool)), emailWindow, SLOT(close()));

    emailWindow->show();

}

void MainWindow::saveEmail()
{
    QString EA = EAddress->text();
    QString EP = EPassW->text();
    QString HN = hostN->currentText();
    QString TN = terminalN->currentText();
    QString selectql = QString(" SELECT * FROM EMAIL_INFO");
    queryd->exec(selectql);
    if(queryd->first()){
    QString deletesql = QString("DELETE FROM EMAIL_INFO");
    queryd->exec(deletesql);
    }
    QString ssql = QString("insert into EMAIL_INFO values('%1','%2','%3','%4')").arg(EA).arg(EP).arg(HN).arg(TN);
    queryd->exec(ssql);

}
