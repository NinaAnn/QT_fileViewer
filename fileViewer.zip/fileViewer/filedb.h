#ifndef FILEDB_H
#define FILEDB_H

#include <QSqlDatabase>
#include <QDialog>
#include <QMessageBox>
#include <QObject>
#include <QSqlError>
#include <QSqlQuery>
#include <QDesktopServices>
#include <QDir>
#include <QDebug>

class fileDB
{
public:
    fileDB();
    static int connect();
};

#endif // FILEDB_H
