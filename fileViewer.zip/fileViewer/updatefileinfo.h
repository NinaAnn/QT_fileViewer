#ifndef UPDATEFILEINFO_H
#define UPDATEFILEINFO_H

#include <QDebug>
#include <QDir>
#include<QFile>
#include <QFileInfo>
#include <QDateTime>
#include <QTimer>
#include <QDesktopServices>
#include "filedb.h"
class UpdatefileInfo
{
public:
    UpdatefileInfo();
private:
    void updateremain(QString path);
    QSqlDatabase db;
    QSqlQuery *query;
private slots:
    void testDesk();

};

#endif // UPDATEFILEINFO_H
