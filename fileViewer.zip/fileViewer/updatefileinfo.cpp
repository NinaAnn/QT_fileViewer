#include "updatefileinfo.h"

UpdatefileInfo::UpdatefileInfo()
{
    //建立database
    db = QSqlDatabase::database("conn");
    query = new QSqlQuery(db);
    query->setForwardOnly(true);

    if(!query->exec("create table FILE_INFO(name nvarchar(40), rout nvarchar(100),suffix nvarchar(20), "
                "createdDate nvarchar(20), lastModifiedD nvarchar(20), size nvarchar(50))")){qDebug()<<query->lastError();}




    QString clear_sql = "delete from FILE_INFO";
    query->prepare(clear_sql);
    /*QString clear_sql2 = "delete from DESK_INFO";
    queryd->prepare(clear_sql2);*/

    QString rootPath(QStandardPaths::writableLocation(QStandardPaths::HomeLocation));
    //QString rootPath = QString("/Users");
    QDir rootDir;
    rootDir.setPath( rootPath );
    QStringList rList;
    rList << "*";
    QFileInfoList rootlist = rootDir.entryInfoList( rList );
    for ( unsigned int i = 0; i < rootlist.count(); i++ )
    {
         QFileInfo rtmpFileInfo = rootlist.at( i );
            if ( rtmpFileInfo.isDir() )
            {
                 QString rstr = rtmpFileInfo.fileName();
                if(rstr!="."&&rstr!=".."){updateremain(rtmpFileInfo.absoluteFilePath());}
            }
            else
            {
                QString fileName = rtmpFileInfo.baseName();
                QString filePath = rtmpFileInfo.absoluteFilePath();
                QString fileSuffix = rtmpFileInfo.suffix();

                //qint64 size = rtmpFileInfo.size();
                char Unit = 'B';
                quint64 curSize = rtmpFileInfo.size();
                if(curSize>1024)
                {
                    curSize/=1024; Unit = 'K';
                    if(curSize>1024)
                    {
                        curSize/=1024; Unit = 'M';
                        if(curSize>1024)
                        {
                            curSize/=1024; Unit = 'G';
                        }
                    }

                }

                QString fileSize = QString::number(curSize,10)+Unit;
                QString fileCreated = rtmpFileInfo.created().toString(QObject::tr("yyyy年MM月dd日hh:mm"));
                QString fileModified = rtmpFileInfo.lastModified().toString(QObject::tr("yyyy年MM月dd日hh:mm"));
                QString ssql = QString("insert into FILE_INFO values('%1','%2','%3','%4','%5','%6')").arg(fileName)
                        .arg(filePath).arg(fileSuffix).arg(fileCreated).arg(fileModified).arg(fileSize);
                query->exec(ssql);

            }
     }
}

void UpdatefileInfo::updateremain(QString path)
{
    QDir rDir;
    rDir.setPath( path );
    QStringList reList;
    reList << "*";
    QFileInfoList rlist = rDir.entryInfoList( reList );
    for ( unsigned int i = 0; i < rlist.count(); i++ )
    {
         QFileInfo retmpFileInfo = rlist.at( i );
            if ( retmpFileInfo.isDir() )
            {
                QString restr = retmpFileInfo.fileName();
                if(restr!="."&&restr!=".."){updateremain(retmpFileInfo.absoluteFilePath());}
            }
            else
            {
                QString fileName = retmpFileInfo.baseName();
                QString filePath = retmpFileInfo.absoluteFilePath();
                QString fileSuffix = retmpFileInfo.suffix();


                char Unit = 'B';
                quint64 curSize = retmpFileInfo.size();
                if(curSize>1024)
                {
                    curSize/=1024; Unit = 'K';
                    if(curSize>1024)
                    {
                        curSize/=1024; Unit = 'M';
                        if(curSize>1024)
                        {
                            curSize/=1024; Unit = 'G';
                        }
                    }

                }
                QString fileSize = QString::number(curSize, 10)+Unit;

                QString fileCreated = retmpFileInfo.created().toString(QObject::tr("yyyy年MM月dd日hh:mm"));
                QString fileModified = retmpFileInfo.lastModified().toString(QObject::tr("yyyy年MM月dd日hh:mm"));
                QString rsql = QString("insert into FILE_INFO values('%1','%2','%3','%4','%5','%6')").arg(fileName)
                        .arg(filePath).arg(fileSuffix).arg(fileCreated).arg(fileModified).arg(fileSize);
                query->exec(rsql);
            }
     }
}

