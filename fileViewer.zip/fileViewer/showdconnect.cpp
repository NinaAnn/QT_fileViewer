#include "showdconnect.h"

showDConnect::showDConnect(QWidget *parent)
 :QDialog(parent)
{
    deskdb = QSqlDatabase::database("desk");
    queryd = new QSqlQuery(deskdb);
    queryd->setForwardOnly(true);

    SRoot = new QLineEdit(this);
    conFile = new QTreeWidget(this);
    sr= new QLabel(tr("源文件地址"));

    QHBoxLayout *sLayout = new QHBoxLayout;
    sLayout->addWidget(sr);
    sLayout->addWidget(SRoot);
    QVBoxLayout *Layout = new QVBoxLayout;
    Layout->addWidget(conFile);
    Layout->addLayout(sLayout);
    setLayout(Layout);

    QStringList headers;
    headers << "文件名"<<"源文件路径";
    conFile->setHeaderLabels(headers);

    QString sql = QString("SELECT name,sourceRoot FROM DESK_FILE");
    queryd->exec(sql);
    if(queryd->first()){
    do
    {
        QString fileN = queryd->value(0).toString();
        QString Sroot = queryd->value(1).toString();
        QStringList sText;
        sText << fileN<<Sroot;
        QTreeWidgetItem *sTmp = new QTreeWidgetItem(conFile, sText);
        //smpTmp->setIcon(0,QIcon( ":/image/file" ));
        conFile->addTopLevelItem( sTmp );
    }while(queryd->next());}
    connect( conFile, SIGNAL( itemDoubleClicked( QTreeWidgetItem *,int ) ), this, SLOT( showRPath( QTreeWidgetItem * ) ) );

}

void showDConnect::showRPath(QTreeWidgetItem *sitem)
{
    QString itemPath = sitem->text(1);
    SRoot->setText(itemPath) ;
}
