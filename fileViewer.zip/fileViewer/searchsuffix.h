#ifndef SEARCHSUFFIX_H
#define SEARCHSUFFIX_H

#include <QDialog>
#include <QWidget>
#include <QListWidget>
#include <QFileInfo>
#include <QDir>
#include <QLineEdit>
#include <QListWidgetItem>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QDebug>
#include <QTreeWidget>
#include <QPoint>
#include <QAction>
#include <QMenu>
#include <QMessageBox>
#include <QLabel>
#include <QDateTime>
#include <QComboBox>
#include <QTcpSocket>
#include <QFileIconProvider>
#include <QDesktopServices>
#include "filedb.h"

class searchsuffix: public QDialog
{
    Q_OBJECT
public:
    searchsuffix(QDialog *parent=0);
    ~searchsuffix();

public slots:
    void getRoot(QString *root);

protected slots:
    void searchsuff();
    void slotshowPath(QTreeWidgetItem *sufitem);
    void popMenu(const QPoint &);
    void detailItem();
    void deleteItem();
    void emailItem();
    void updateItem();
    void closeE();
private:
    QLineEdit *suffix;
    QLineEdit *rout;
    QLineEdit *Name;
    QLineEdit *receivAddr;
    QComboBox *Year;
    QComboBox *Month;
    QComboBox *Date;
    QComboBox *LYear;
    QComboBox *LMonth;
    QComboBox *LDate;
    QTreeWidget *sufListwidget;
    //QSqlDatabase db;
    //QSqlQuery *query;
    QSqlDatabase deskdb;
    QSqlQuery *queryd;
    int matchNom(QString nom, QString name);
    void searchremain(QString path);
    bool DeleteDirectory(QString path);

};



#endif // SEARCHSUFFIX_H



