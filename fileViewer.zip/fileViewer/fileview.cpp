#include "fileview.h"
#include "sendemailapi/smtpmime.h"

fileview::fileview(QWidget *parent)
: QDialog(parent)
{
    setWindowTitle( tr( "File Viewer" ) );
    this->resize(600,400);
     pLineEditDir = new QLineEdit;
     receivAddr = new QLineEdit;
     QString rpath(QStandardPaths::writableLocation(QStandardPaths::HomeLocation));
         pLineEditDir->setText( rpath );
     pListWidgetFile = new QTreeWidget(this);
     QStringList headers;
     headers << "Name"<<"Path";
     pListWidgetFile->setHeaderLabels(headers);
     pListWidgetFile->setColumnWidth(0,450);
     QPushButton *searchbutton = new QPushButton(QObject::tr("&在当前文件夹搜索"));

     /*db = QSqlDatabase::database("conn");
     query = new QSqlQuery(db);
     query->setForwardOnly(true);*/

     deskdb = QSqlDatabase::database("desk");
     queryd = new QSqlQuery(deskdb);
     queryd->setForwardOnly(true);

     leftLayout = new QVBoxLayout;
         leftLayout->addWidget(pListWidgetFile);
         leftLayout->addWidget(pLineEditDir);
         leftLayout->addWidget(searchbutton);
     //QWidget *mainWidget = new QWidget;
         //mainWidget->setLayout(leftLayout);
     //searchsuffix *search = new searchsuffix(this);
     connect(searchbutton, SIGNAL(clicked(bool)), this, SLOT(searchShow()));

     connect( pListWidgetFile, SIGNAL( itemDoubleClicked( QTreeWidgetItem * ,int) ), this, SLOT( slotShowDir( QTreeWidgetItem * ) ) );

     QString root( QStandardPaths::writableLocation(QStandardPaths::HomeLocation) );
     QDir rootDir( root );
     QStringList sList;
     sList << "*";
     QFileInfoList list = rootDir.entryInfoList( sList );
     showFileInfoList( list );
     setLayout(leftLayout);

     pListWidgetFile->setContextMenuPolicy(Qt::CustomContextMenu);
     connect(pListWidgetFile,SIGNAL(customContextMenuRequested(const QPoint&)),this,SLOT(popupMenu(const QPoint&)));

}

fileview::~fileview()
{

}

void fileview::searchShow()
{
    searchsuffix *search = new searchsuffix(this);
    QString root = pLineEditDir->text();
    QObject::connect(this, SIGNAL(sendRoot(QString*)),search,SLOT(getRoot(QString*)));
    emit sendRoot(&root);
    leftLayout->addWidget(search);

}

void fileview::showFileInfoList( QFileInfoList list )
{
       pListWidgetFile->clear();
       for ( unsigned int i = 0; i < list.count(); i++ )
       {
              QFileInfo tmpFileInfo = list.at( i );

              if ( tmpFileInfo.isDir() )
              {
                     QString fileName = tmpFileInfo.fileName();
                     QString filePath = tmpFileInfo.absolutePath();
                     QStringList plistText;
                     plistText << fileName<<filePath;
                     QTreeWidgetItem * Tmp = new QTreeWidgetItem(pListWidgetFile, plistText);
                     Tmp->setIcon(0,QIcon( ":/image/dir" ));
                     pListWidgetFile->addTopLevelItem(Tmp);
              }
              else
              {
                     QString fileName = tmpFileInfo.fileName();
                     QString filePath = tmpFileInfo.absoluteFilePath();
                     //QListWidgetItem * pTmp = new QListWidgetItem( QIcon( ":/image/file" ), fileName );
                     //pListWidgetFile->addItem( pTmp );
                     QStringList plistText;
                     QFileIconProvider iconPro;
                     QIcon icon = iconPro.icon(tmpFileInfo);
                     plistText << fileName<<filePath;
                     QTreeWidgetItem *Tmp = new QTreeWidgetItem(pListWidgetFile, plistText);
                     Tmp->setIcon(0,QIcon(icon));
                     pListWidgetFile->addTopLevelItem(Tmp );
              }
       }
}

void fileview::slotShowDir( QTreeWidgetItem * item )
{
       QString str = item->text(0);
       QDir dir;
       dir.setPath( pLineEditDir->text() );
       dir.cd( str );
       pLineEditDir->setText( dir.absolutePath() );

       QStringList string;
       string << "*";

       QFileInfoList list = dir.entryInfoList( string, QDir::AllEntries, QDir::DirsFirst );
       showFileInfoList( list );
}

void fileview::popupMenu(const QPoint &)
{
    QTreeWidgetItem* curItem= pListWidgetFile->currentItem();
    if(curItem==NULL)return;
    QString wellName = curItem->text(0);
    QString itemPath = curItem->text(1);
    QFileInfo detailfile(itemPath);
    if(detailfile.isDir())
    {
        return;
    }
    if(wellName != "wells")
        {
            QAction readdetail(QString::fromLocal8Bit("&查看信息"),this);
            QAction deletefile(QString::fromLocal8Bit("&删除文件"),this);
            QAction updateConnection(QString::fromLocal8Bit("&桌面同步"),this);
            QAction sendfileEmail(QString::fromLocal8Bit("&发送邮件"),this);
            connect(&readdetail, SIGNAL(triggered()), this, SLOT(detailItem()));
            connect(&deletefile, SIGNAL(triggered()), this, SLOT(deleteItem()));
            connect(&sendfileEmail, SIGNAL(triggered()), this, SLOT(emailItem()));
            connect(&updateConnection, SIGNAL(triggered()), this, SLOT(updateItem()));
           // connect(&reNameWell,SIGNAL(triggered()),this,SLOT(renameWell()));
            QMenu menu(pListWidgetFile);
            menu.addAction(&readdetail);
            menu.addAction(&deletefile);
            menu.addAction(&updateConnection);
            menu.addAction(&sendfileEmail);
            menu.exec(QCursor::pos());  //在当前鼠标位置显示

        }
}
void fileview::detailItem()
{
    QTreeWidgetItem* currItem=pListWidgetFile->currentItem();
    QString itemPath = currItem->text(1);
    QFileInfo filenew(itemPath);
    QDialog *fileDWindow = new QDialog(this);
    fileDWindow->setWindowTitle(tr("文件信息"));
    QLabel *fileN = new QLabel(tr("文件名:"));
    QLabel *fileS = new QLabel(tr("文件后缀:"));
    QLabel *fileR = new QLabel(tr("文件路径:"));
    QLabel *fileSZ = new QLabel(tr("文件大小"));
    QLabel *fileC = new QLabel(tr("创建时间:"));
    QLabel *fileE = new QLabel(tr("最后修改时间:"));
    QLineEdit *fileName = new QLineEdit(fileDWindow);
    QLineEdit *fileSuffix = new QLineEdit(fileDWindow);
    QLineEdit *fileRout = new QLineEdit(fileDWindow);
    QLineEdit *fileSize = new QLineEdit(fileDWindow);
    QLineEdit *fileCreated = new QLineEdit(fileDWindow);
    QLineEdit *fileEdit = new QLineEdit(fileDWindow);

    /*
    QString sqlN = QString("SELECT name,suffix,createdDate,lastModifiedD,size FROM FILE_INFO WHERE rout='%1'").arg(itemPath);
        query->exec(sqlN);
        if(query->first()){
        fileName->setText( query->value(0).toString());
        fileSuffix->setText("."+query->value(1).toString());
        fileCreated->setText(query->value(2).toString());
        fileEdit->setText(query->value(3).toString());
        fileSize->setText(query->value(4).toString());}
        else
            qDebug()<<query->lastError();
    fileRout->setText(itemPath);
    */
    fileName->setText(filenew.baseName());
    fileSuffix->setText("."+filenew.suffix());
    fileRout->setText(itemPath);
    fileCreated->setText(filenew.created().toString(QObject::tr("yyyy年MM月dd日hh:mm")));
    fileEdit->setText(filenew.lastModified().toString(QObject::tr("yyyy年MM月dd日hh:mm")));
    char Unit = 'B';
    quint64 curSize = filenew.size();
    if(curSize>1024)
    {
        curSize/=1024; Unit = 'K';
        if(curSize>1024)
        {
            curSize/=1024; Unit = 'M';
            if(curSize>1024)
            {
                curSize/=1024; Unit = 'G';
            }
        }

    }
    QString filesize = QString::number(curSize, 10)+Unit;
    fileSize->setText(filesize);

    QGridLayout *gridLayout=new QGridLayout;
    gridLayout->setSizeConstraint(QLayout::SetFixedSize);
    //gridLayout->setSpacing(12);
    gridLayout->addWidget(fileN,0,0,1,1);
    gridLayout->addWidget(fileName,0,1,1,8);
    gridLayout->addWidget(fileS,0,15,1,1);
    gridLayout->addWidget(fileSuffix,0,16,1,4);
    gridLayout->addWidget(fileR,1,0,1,1);
    gridLayout->addWidget(fileRout,1,1,1,30);
    gridLayout->addWidget(fileSZ,2,0,1,1);
    gridLayout->addWidget(fileSize,2,1,1,4);
    gridLayout->addWidget(fileC,3,0,1,1);
    gridLayout->addWidget(fileCreated,3,1,1,8);
    gridLayout->addWidget(fileE,3,15,1,1);
    gridLayout->addWidget(fileEdit,3,16,1,15);

    fileDWindow->setLayout(gridLayout);
    fileDWindow->show();
}

void fileview::deleteItem()
{

         if(QMessageBox::warning(NULL, "warning", "Do you want to delete this file?",
                                 QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes) == QMessageBox::Yes)
         {
        QTreeWidgetItem* current = pListWidgetFile->currentItem();
        QString itemPath = current->text(1);
        DeleteDirectory(itemPath);
        delete current;
         }

}

bool fileview::DeleteDirectory(QString path)
{
    QFileInfo deletefile(path);
    if(!deletefile.exists())
            return true;
    deletefile.dir().remove(deletefile.fileName());
    return true;

}

void fileview::updateItem()
{
    QTreeWidgetItem* currItem=pListWidgetFile->currentItem();
    QString itemPath = currItem->text(1);
    QString itemName = currItem->text(0);
    QFileInfo filenew(itemPath);
    QString ssql = QString("SELECT name FROM DESK_FILE WHERE sourceRoot='%5'").arg(itemPath);
    queryd->exec(ssql);
    if(queryd->first())
    {
        QMessageBox::warning(NULL, "warning", "该文件已存在桌面同步文件",
                                      QMessageBox::Ok |QMessageBox::Ok);
        return;
    }
    QString DS(QStandardPaths::writableLocation(QStandardPaths::DesktopLocation));
    QString toDesktop(DS+"/");
    QDir sourceDir;
    QDir deskDir;
    QString newPath = toDesktop+itemName;
    deskDir.setPath(newPath);
    sourceDir.setPath(itemPath);
    QFile::copy(itemPath,newPath);
    QString lastMD;
    lastMD = filenew.lastModified().toString(QObject::tr("yyyy年MM月dd日hh:mm"));
    /*
    QString sql = QString("SELECT lastModifiedD FROM FILE_INFO WHERE rout='%4'").arg(itemPath);
        query->exec(sql);
        if(query->first())
        lastMD = query->value(0).toString();*/
    QString dsql = QString("insert into DESK_FILE values('%1','%2','%3','%4')").arg(itemName)
            .arg(itemPath).arg(newPath).arg(lastMD);
    queryd->exec(dsql);
}

void fileview::emailItem()
{
    QDialog *receiverAddr = new QDialog(this);
    QLabel *rece = new QLabel(tr("收件人邮箱："));
    QPushButton *recebutton = new QPushButton(QObject::tr("&确认发送"));
    connect(recebutton,SIGNAL(clicked(bool)),this,SLOT(sendE()));
    QVBoxLayout *rLayout = new QVBoxLayout;
    rLayout->addWidget(rece);
    rLayout->addWidget(receivAddr);
    rLayout->addWidget(recebutton);
    receiverAddr->setLayout(rLayout);
    receiverAddr->show();
    connect(recebutton,SIGNAL(clicked(bool)),receiverAddr,SLOT(close()));
}

void fileview::sendE()
{
    if(receivAddr->text() == "")
    {
        QMessageBox::warning(NULL, "warning", "请输入收件人邮箱地址！",
                             QMessageBox::Ok |QMessageBox::Ok);
        return;
    }
    QTreeWidgetItem* currItem=pListWidgetFile->currentItem();
    QString itemPath = currItem->text(1);
    QString itemName = currItem->text(0);
    //qDebug()<<itemPath;
    QString hostNm;
    QString termNb;
    QString UserNm;
    QString PassWN;
    QString esql = QString("SELECT * FROM EMAIL_INFO");
    queryd->exec(esql);
    if(queryd->first())
    {
     UserNm = queryd->value(0).toString();
     PassWN = queryd->value(1).toString();
     hostNm = queryd->value(2).toString();
     termNb = queryd->value(3).toString();
    }
    quint64 num = termNb.toInt();
    SmtpClient smtp(hostNm,num);
    smtp.setUser(UserNm);
    smtp.setPassword(PassWN);

    MimeMessage message;
    message.setSender(new EmailAddress(UserNm));
    QString receiver = receivAddr->text();
    message.addRecipient(new EmailAddress(receiver));
    message.setSubject(itemName);
    MimeHtml text;
    text.setHtml("sent from qt host");
    message.addPart(&text);

    QFile *attafile = new QFile(itemPath);
    if(attafile->exists())
    {
        message.addPart(new MimeAttachment(attafile));
    }

    if (!smtp.connectToHost()){
            QMessageBox::critical(this,"错误","服务器连接失败!");
            return;
        }
        if (!smtp.login()){
            QMessageBox::critical(this,"错误","用户登录失败!");
            return;
        }
        if (!smtp.sendMail(message)){
            QMessageBox::critical(this,"错误","邮件发送失败!");
            return;
        }else{
            QMessageBox::information(this,"错误","邮件发送成功!");
        }
    smtp.quit();
}
