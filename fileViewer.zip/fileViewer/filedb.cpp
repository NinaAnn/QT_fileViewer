#include "filedb.h"

fileDB::fileDB()
{

}

int fileDB::connect()
{
    QString fileP = QDir::homePath();
    //qDebug()<<fileP;
    //QString strDBFile = fileP+"/Documents/fileinfo.db";
    QString strDBFile2 = fileP+"/Documents/deskfileinfo.db";
    /*QDir dir(strDBFile);
            if(!dir.exists()){
                dir.mkdir(fileP);
            }*/
   QDir dir2(strDBFile2);
         if(!dir2.exists()){
                dir2.mkdir(fileP);
                    }

    /*if(!QFile::exists(strDBFile))
    QFile(strDBFile);*/
    if(!QFile::exists(strDBFile2))
    QFile(strDBFile2);
        //QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE","conn");
        //db.setDatabaseName(strDBFile);
        //db.setDatabaseName(":memory:");


        QSqlDatabase deskdb = QSqlDatabase::addDatabase("QSQLITE","desk");
        deskdb.setDatabaseName(strDBFile2);
        //deskdb.setDatabaseName(":memory:");

    /*if (!db.open()) {
            QMessageBox::critical(0, QObject::tr("Database Error"),
                                  db.lastError().text());
            return false;
    }*/
    if(!deskdb.open())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"),
                              deskdb.lastError().text());
        return false;
    }
    else
    {
        return true;}
}
