#include "mainwindow.h"
#include "fileview.h"
#include "filedb.h"
#include <QApplication>
#include <QObject>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QFile::remove(QDir::homePath()+"/Documents/fileinfo.db");
    //QFile::remove("deskfileinfo.db");
    if(!fileDB::connect())
    {
        return 1;
    }


    MainWindow window;
    window.show();
    return a.exec();
}
