#ifndef SHOWDCONNECT_H
#define SHOWDCONNECT_H

#include <QObject>
#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QTreeWidget>

class showDConnect: public QDialog
{
    Q_OBJECT
public:
    showDConnect(QWidget *parent=0);
private:
    QSqlDatabase deskdb;
    QSqlQuery *queryd;
    QLineEdit *SRoot;
    QLabel *sr;
    QTreeWidget *conFile;
protected slots:
    void showRPath(QTreeWidgetItem * sitem);
};

#endif // SHOWDCONNECT_H
